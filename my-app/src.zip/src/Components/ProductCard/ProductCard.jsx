import React from 'react';
import './ProductCard.css';

function ProductCard({ product, onBuy }) {
  const handleBuy = () => {
    if (onBuy) {
      onBuy(product);
    } else {
      console.log(`Buying ${product.name}`);
    }
  };

  return (
    <div className="product-card">
      <h3 className="product-name">{product.name}</h3>
      <p className="product-description">{product.description}</p>
      <strong className="product-price">₱{product.price}</strong>
      <button className="buy-button" onClick={handleBuy}>
        BUY ME
      </button>
    </div>
  );
}

export default ProductCard;