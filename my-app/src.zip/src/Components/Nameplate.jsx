import * as React from 'react';
import {useState} from 'react';

function Nameplate(props) {
  const plateStyle = {
    border: '1px solid black',
    margin: '3px',
    padding: '10px',
    width: '150px',
  };

  const [count, setCount] = useState(0);

  return (
    <div style={plateStyle}>
      <u>{props.platename}</u>
      <p>{props.course}</p>
      <p>{props.year}</p>
      <p>{props.gender}</p>
      <p>{props.definition}</p>
      <button variant='outlined'
      		  onClick = {() =>
      		  	(setCount(count + 1))}>{count}</button>
    </div>
  );
}

export default Nameplate;
