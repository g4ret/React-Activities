import React, { useState } from 'react';

export default function Shopping() {
  const [cart, setCart] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState('gadget');

  const allProducts = {
    gadget: [
      {
        id: 1,
        name: "Wireless Bluetooth Headphones",
        description: "High-quality wireless headphones with noise cancellation and 30-hour battery life. Perfect for music lovers and professionals.",
        price: 99.99,
        image: "https://via.placeholder.com/250x250/4A90E2/FFFFFF?text=Headphones"
      },
      {
        id: 2,
        name: "Smart Fitness Watch",
        description: "Advanced fitness tracker with heart rate monitoring, GPS, and waterproof design. Track your health and stay connected.",
        price: 249.99,
        image: "https://via.placeholder.com/250x250/50C878/FFFFFF?text=Smart+Watch"
      }
    ],
    clothes: [
      {
        id: 3,
        name: "DIOR Luxury Sweater",
        description: "Premium cashmere sweater from Christian Dior's latest collection. Elegant design with superior comfort and timeless style.",
        price: 1299.99,
        image: "https://via.placeholder.com/250x250/FFB6C1/FFFFFF?text=DIOR"
      },
      {
        id: 4,
        name: "LACOSTE Polo Shirt",
        description: "Classic Lacoste polo shirt made from premium cotton piqué. Iconic crocodile logo and perfect fit for sophisticated casual wear.",
        price: 89.99,
        image: "https://via.placeholder.com/250x250/98FB98/FFFFFF?text=LACOSTE"
      }
    ],
    merch: [
      {
        id: 5,
        name: "ILLIT - Super Real Me Album",
        description: "ILLIT's debut mini album 'Super Real Me' featuring hit tracks and exclusive photobook. Limited edition with special inclusions.",
        price: 24.99,
        image: "https://via.placeholder.com/250x250/DDA0DD/FFFFFF?text=ILLIT"
      },
      {
        id: 6,
        name: "NewJeans - The 2nd EP Album",
        description: "NewJeans' second EP album with all the beloved tracks. Includes photobook, photocards, and exclusive poster.",
        price: 22.99,
        image: "https://via.placeholder.com/250x250/F0E68C/FFFFFF?text=NewJeans"
      }
    ]
  };

  const categories = [
    { id: 'gadget', name: 'Gadgets', icon: '📱' },
    { id: 'clothes', name: 'Clothes', icon: '👕' },
    { id: 'merch', name: 'Merch', icon: '🎵' }
  ];

  const addToCart = (product) => {
    setCart([...cart, product]);
    alert(`${product.name} added to cart!`);
  };

  const buyNow = (product) => {
    alert(`Proceeding to checkout for ${product.name} - $${product.price}`);
  };

  return (
    <div style={{ 
      display: 'flex',
      fontFamily: 'Arial, sans-serif',
      backgroundColor: '#f5f5f5',
      minHeight: '100vh'
    }}>
      {/* Left Sidebar for Categories */}
      <div style={{
        width: '200px',
        backgroundColor: '#2c3e50',
        padding: '20px',
        boxShadow: '2px 0 5px rgba(0,0,0,0.1)'
      }}>
        <h2 style={{
          color: 'white',
          marginBottom: '30px',
          fontSize: '1.5rem',
          textAlign: 'center'
        }}>
          Categories
        </h2>
        
        {categories.map(category => (
          <button
            key={category.id}
            onClick={() => setSelectedCategory(category.id)}
            style={{
              display: 'block',
              width: '100%',
              padding: '15px 20px',
              marginBottom: '10px',
              backgroundColor: selectedCategory === category.id ? '#3498db' : 'transparent',
              color: 'white',
              border: selectedCategory === category.id ? 'none' : '1px solid #34495e',
              borderRadius: '8px',
              fontSize: '1rem',
              cursor: 'pointer',
              transition: 'all 0.3s ease',
              textAlign: 'left'
            }}
            onMouseEnter={(e) => {
              if (selectedCategory !== category.id) {
                e.target.style.backgroundColor = '#34495e';
              }
            }}
            onMouseLeave={(e) => {
              if (selectedCategory !== category.id) {
                e.target.style.backgroundColor = 'transparent';
              }
            }}
          >
            <span style={{ marginRight: '10px', fontSize: '1.2rem' }}>
              {category.icon}
            </span>
            {category.name}
          </button>
        ))}
      </div>

      {/* Main Content Area */}
      <div style={{ 
        flex: 1,
        padding: '20px 40px'
      }}>
        <h1 style={{ 
          textAlign: 'center', 
          marginBottom: '40px',
          color: '#333',
          fontSize: '2.5rem',
          textTransform: 'uppercase'
        }}>
          {categories.find(cat => cat.id === selectedCategory)?.name} Collection
        </h1>
        
        <div style={{
          display: 'flex',
          gap: '30px',
          justifyContent: 'center',
          flexWrap: 'wrap',
          maxWidth: '1200px',
          margin: '0 auto'
        }}>
          {allProducts[selectedCategory].map(product => (
            <div key={product.id} style={{
              backgroundColor: 'white',
              borderRadius: '12px',
              boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)',
              overflow: 'hidden',
              width: '350px',
              transition: 'transform 0.2s ease',
              display: 'flex',
              flexDirection: 'column'
            }}
            onMouseEnter={(e) => e.currentTarget.style.transform = 'translateY(-5px)'}
            onMouseLeave={(e) => e.currentTarget.style.transform = 'translateY(0)'}
            >
              {/* Product Info Top */}
              <div style={{ padding: '20px 20px 10px 20px' }}>
                <h2 style={{
                  margin: '0',
                  fontSize: '1.4rem',
                  color: '#333',
                  fontWeight: 'bold',
                  textAlign: 'center'
                }}>
                  {product.name}
                </h2>
              </div>

              {/* Square Image in Middle */}
              <div style={{
                display: 'flex',
                justifyContent: 'center',
                alignItems: 'center',
                padding: '20px',
                minHeight: '290px'
              }}>
                <img 
                  src={product.src}
                  alt={product.name}
                  style={{
                    width: '250px',
                    height: '250px',
                    objectFit: 'cover',
                    backgroundColor: '#e0e0e0',
                    borderRadius: '8px',
                    border: '2px solid #f0f0f0'
                  }}
                />
              </div>
              
              {/* Product Info Bottom */}
              <div style={{ 
                padding: '20px',
                flex: 1,
                display: 'flex',
                flexDirection: 'column'
              }}>
                <p style={{
                  margin: '0 0 15px 0',
                  color: '#666',
                  lineHeight: '1.5',
                  fontSize: '0.9rem',
                  textAlign: 'center',
                  flex: 1
                }}>
                  {product.description}
                </p>
                
                <div style={{
                  fontSize: '1.8rem',
                  fontWeight: 'bold',
                  color: '#e74c3c',
                  margin: '15px 0 20px 0',
                  textAlign: 'center'
                }}>
                  ${product.price}
                </div>
                
                {/* Buttons */}
                <div style={{
                  display: 'flex',
                  gap: '10px',
                  justifyContent: 'space-between'
                }}>
                  <button
                    onClick={() => addToCart(product)}
                    style={{
                      flex: 1,
                      padding: '12px 20px',
                      backgroundColor: '#f8f9fa',
                      color: '#333',
                      border: '2px solid #dee2e6',
                      borderRadius: '6px',
                      fontSize: '1rem',
                      fontWeight: '500',
                      cursor: 'pointer',
                      transition: 'all 0.2s ease'
                    }}
                    onMouseEnter={(e) => {
                      e.target.style.backgroundColor = '#e9ecef';
                      e.target.style.borderColor = '#adb5bd';
                    }}
                    onMouseLeave={(e) => {
                      e.target.style.backgroundColor = '#f8f9fa';
                      e.target.style.borderColor = '#dee2e6';
                    }}
                  >
                    Add to Cart
                  </button>
                  
                  <button
                    onClick={() => buyNow(product)}
                    style={{
                      flex: 1,
                      padding: '12px 20px',
                      backgroundColor: '#007bff',
                      color: 'white',
                      border: 'none',
                      borderRadius: '6px',
                      fontSize: '1rem',
                      fontWeight: '500',
                      cursor: 'pointer',
                      transition: 'background-color 0.2s ease'
                    }}
                    onMouseEnter={(e) => e.target.style.backgroundColor = '#0056b3'}
                    onMouseLeave={(e) => e.target.style.backgroundColor = '#007bff'}
                  >
                    Buy Now
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
      
      {/* Cart Counter */}
      {cart.length > 0 && (
        <div style={{
          position: 'fixed',
          top: '20px',
          right: '20px',
          backgroundColor: '#28a745',
          color: 'white',
          padding: '10px 15px',
          borderRadius: '20px',
          fontSize: '0.9rem',
          fontWeight: 'bold',
          zIndex: 1000
        }}>
          Cart: {cart.length} items
        </div>
      )}
    </div>
  );
}