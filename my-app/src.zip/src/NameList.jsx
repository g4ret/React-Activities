import * as React from 'react';
import {useState} from 'react';


export default function NameList(){
	const list = [
		{id: 1, studentName: 'Gee Caliph', course: 'BSIT', year: '3'},
		{id: 1, studentName: 'Gee Caliph', course: 'BSIT', year: '3'},
		{id: 1, studentName: 'Gee Caliph', course: 'BSIT', year: '3'},
		{id: 1, studentName: 'Gee Caliph', course: 'BSIT', year: '3'},
		{id: 1, studentName: 'Gee Caliph', course: 'BSIT', year: '3'},
	];

	const listOfNames = list.map(item => <nameCard nameDisplay={item.studentName} 
													course ={item.course}
													bgc ={item.bgc}/>)

	const [studentIndex, setStudent] =useState(0);

	return (
		<>
			<h1>List Of Students</h1>
			<nameCard nameData = {list[studentIndex]} />

			<button onClick=[()=> setStudent(studentIndex -1)]>Previous</button>
			<button>Next</button>
		</>) 
}