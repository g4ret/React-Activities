import React from 'react';
import Shopping from './Components/Shopping/Shopping';
import './App.css';

function App() {
  return (
    <div className="App">
      <Shopping />
    </div>
  );
}

export default App;